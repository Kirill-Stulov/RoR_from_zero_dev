require 'test_helper'

class PassangerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
