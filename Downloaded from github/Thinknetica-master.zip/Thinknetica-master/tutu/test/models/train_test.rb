require 'test_helper'

class TrainTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
