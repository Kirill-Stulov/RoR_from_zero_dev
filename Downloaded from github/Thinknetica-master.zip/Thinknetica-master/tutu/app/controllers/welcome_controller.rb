class WelcomeController < ApplicationController
  def index
  end

  def admin
  end
end
