class Wagon
	include Manufacturer
end
