class CargoWagon < Wagon
end