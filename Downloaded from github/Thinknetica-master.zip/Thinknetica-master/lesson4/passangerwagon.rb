class PassangerWagon < Wagon
  
end