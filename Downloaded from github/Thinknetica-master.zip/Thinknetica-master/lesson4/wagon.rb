class Wagon

end
